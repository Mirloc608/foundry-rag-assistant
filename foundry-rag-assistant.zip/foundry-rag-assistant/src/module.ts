import { RagControlPanel } from "./ragPanel";
import { RagChatSidebar } from "./chatSidebar";
import { registerSettings } from "./settings";

Hooks.once("init", () => {
  console.log("Foundry RAG Assistant | Initializing");
  registerSettings();
});

Hooks.on("getSceneControlButtons", (controls: any) => {
  // Foundry V12/V13: controls is a SceneControls instance
  const groups = controls.controls;
  if (!Array.isArray(groups)) return;

  const tokenControls = groups.find((c: any) => c.name === "token");
  if (!tokenControls) return;

  tokenControls.tools.push({
    name: "rag-panel",
    title: game.i18n.localize("RAG.Title"),
    icon: "fas fa-brain",
    button: true,
    onClick: () => new RagControlPanel().render(true)
  });
});

Hooks.on("renderChatLog", (_app: any, html: JQuery) => {
  const button = $(`
    <a class="rag-chat-button">
      <i class="fas fa-brain"></i> ${game.i18n.localize("RAG.ChatTitle")}
    </a>
  `);

  button.on("click", ev => {
    ev.preventDefault();
    new RagChatSidebar().render(true);
  });

  html.find(".chat-control-icon").last().after(button);
});



